﻿using Microsoft.AspNetCore.Mvc;
using UserManager.DTO;
using UserManager.Services;

namespace UserManager.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _auth;
        public AuthController(IAuthService auth) => _auth = auth;

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterRequest request)
        {
            var (ok, error) = await _auth.RegisterAsync(request);
            if (!ok) return BadRequest(new { message = error });
            return Ok(new { message = $"User {request.Email} registered." });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            var (token, user, roles) = await _auth.LoginAsync(request);
            if (token == null || user == null)
                return Unauthorized(new { message = "Invalid email or password" });

            var fullName = $"{user.FirstName} {user.LastName}".Trim();
            return Ok(new AuthResponse(token, user.Email!, fullName, string.Join(",", roles)));
        }
    }
}