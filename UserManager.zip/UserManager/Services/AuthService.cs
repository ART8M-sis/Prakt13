﻿using Microsoft.AspNetCore.Identity;
using UserManager.DTO;
using UserManager.Models;

namespace UserManager.Services
{
    public interface IAuthService
    {
        Task<(bool ok, string? error)> RegisterAsync(RegisterRequest request);
        Task<(string? token, AppUser? user, IList<string>? roles)> LoginAsync(LoginRequest request);
    }

    public class AuthService : IAuthService
    {
        private readonly UserManager<AppUser> _userManager;
        private readonly RoleManager<IdentityRole<Guid>> _roleManager;
        private readonly ITokenService _tokenService;

        public AuthService(UserManager<AppUser> userManager,
                           RoleManager<IdentityRole<Guid>> roleManager,
                           ITokenService tokenService)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _tokenService = tokenService;
        }

        public async Task<(bool ok, string? error)> RegisterAsync(RegisterRequest request)
        {
            var user = new AppUser
            {
                UserName = request.Email,
                Email = request.Email,
                FirstName = request.FirstName,
                LastName = request.LastName
            };

            var result = await _userManager.CreateAsync(user, request.Password);
            if (!result.Succeeded)
                return (false, string.Join("; ", result.Errors.Select(e => e.Description)));

            const string roleName = "User";
            if (!await _roleManager.RoleExistsAsync(roleName))
                await _roleManager.CreateAsync(new IdentityRole<Guid>(roleName));

            await _userManager.AddToRoleAsync(user, roleName);
            return (true, null);
        }

        public async Task<(string? token, AppUser? user, IList<string>? roles)> LoginAsync(LoginRequest request)
        {
            var user = await _userManager.FindByEmailAsync(request.Email);
            if (user == null || !await _userManager.CheckPasswordAsync(user, request.Password))
                return (null, null, null);

            var roles = await _userManager.GetRolesAsync(user);
            var token = _tokenService.CreateToken(user, roles);
            return (token, user, roles);
        }
    }
}